#!/usr/bin/env python
# coding: utf-8

# In[11]:


import numpy as np
from scipy.integrate import odeint
import matplotlib.pyplot as plt
import plotly.graph_objects as go
import scipy as sp
from scipy.integrate import solve_ivp
kdna = 0.001
katp = 0.0001
vmax = 8.3*10**-6
ATP = 10**-4

CTA = np.zeros((500,32))
CTE = np.zeros((500,32))


# In[12]:



def concentrations(x,t):
    
    CA = x[0]
    CD = x[1]
    CD1 = x[2]
    CD2 = x[3]
    CD3 = x[4]
    CD4 = x[5]
    CD5 = x[6]
    CD6 = x[7]
    CD7 = x[8]
    CD8 = x[9]
    CD9 = x[10]
    CD10 = x[11]
    CD11 = x[12]
    CD12= x[13]
    CD13= x[14]
    CD14= x[15]
    CD15= x[16]
    CD16= x[17]
    CD17= x[18]
    CD18= x[19]
    CD19= x[20]
    CD20= x[21]
    CD21= x[22]
    CD22= x[23]
    CD23= x[24]
    CD24= x[25]
    CD25= x[26]
    CD26= x[27]
    CD27= x[28]
    CD28= x[29]
    CD29= x[30]
    CD30= x[31]
    
    
    dCAdt = -((vmax*CA*CD)/(kdna*katp+kdna*CA+katp*CD+CA*CD))*t-((vmax*CA*CD1)/(kdna*katp+kdna*CA+katp*CD1+CA*CD1))*t-((vmax*CA*CD1)/(kdna*katp+kdna*CA+katp*CD1+CA*CD1))*t-((vmax*CA*CD2)/(kdna*katp+kdna*CA+katp*CD2+CA*CD2))*t-((vmax*CA*CD3)/(kdna*katp+kdna*CA+katp*CD3+CA*CD3))*t-((vmax*CA*CD4)/(kdna*katp+kdna*CA+katp*CD4+CA*CD4))*t-((vmax*CA*CD5)/(kdna*katp+kdna*CA+katp*CD5+CA*CD5))*t-((vmax*CA*CD6)/(kdna*katp+kdna*CA+katp*CD6+CA*CD6))*t-((vmax*CA*CD7)/(kdna*katp+kdna*CA+katp*CD7+CA*CD7))*t-((vmax*CA*CD8)/(kdna*katp+kdna*CA+katp*CD8+CA*CD8))*t-((vmax*CA*CD9)/(kdna*katp+kdna*CA+katp*CD9+CA*CD9))*t-((vmax*CA*CD10)/(kdna*katp+kdna*CA+katp*CD10+CA*CD10))*t-((vmax*CA*CD11)/(kdna*katp+kdna*CA+katp*CD11+CA*CD11))*t-((vmax*CA*CD12)/(kdna*katp+kdna*CA+katp*CD12+CA*CD12))*t-((vmax*CA*CD13)/(kdna*katp+kdna*CA+katp*CD13+CA*CD13))*t-((vmax*CA*CD14)/(kdna*katp+kdna*CA+katp*CD14+CA*CD14))*t-((vmax*CA*CD15)/(kdna*katp+kdna*CA+katp*CD15+CA*CD15))*t-((vmax*CA*CD16)/(kdna*katp+kdna*CA+katp*CD16+CA*CD16))*t-((vmax*CA*CD17)/(kdna*katp+kdna*CA+katp*CD17+CA*CD17))*t-((vmax*CA*CD18)/(kdna*katp+kdna*CA+katp*CD18+CA*CD18))*t-((vmax*CA*CD19)/(kdna*katp+kdna*CA+katp*CD19+CA*CD19))*t-((vmax*CA*CD20)/(kdna*katp+kdna*CA+katp*CD20+CA*CD20))*t-((vmax*CA*CD21)/(kdna*katp+kdna*CA+katp*CD21+CA*CD21))*t-((vmax*CA*CD22)/(kdna*katp+kdna*CA+katp*CD22+CA*CD22))*t-((vmax*CA*CD23)/(kdna*katp+kdna*CA+katp*CD23+CA*CD23))*t-((vmax*CA*CD24)/(kdna*katp+kdna*CA+katp*CD24+CA*CD24))*t-((vmax*CA*CD25)/(kdna*katp+kdna*CA+katp*CD25+CA*CD25))*t-((vmax*CA*CD26)/(kdna*katp+kdna*CA+katp*CD26+CA*CD26))*t-((vmax*CA*CD27)/(kdna*katp+kdna*CA+katp*CD27+CA*CD27))*t-((vmax*CA*CD28)/(kdna*katp+kdna*CA+katp*CD28+CA*CD28))*t-((vmax*CA*CD29)/(kdna*katp+kdna*CA+katp*CD29+CA*CD29))*t
    dCDdt = -((vmax*CA*CD)/(kdna*katp+kdna*CA+katp*CD+CA*CD))*t
    dCD1dt = ((vmax*CA*CD)/(kdna*katp+kdna*CA+katp*CD+CA*CD))*t-((vmax*CA*CD1)/(kdna*katp+kdna*CA+katp*CD1+CA*CD1))*t
    dCD2dt = ((vmax*CA*CD1)/(kdna*katp+kdna*CA+katp*CD1+CA*CD1))*t-((vmax*CA*CD2)/(kdna*katp+kdna*CA+katp*CD2+CA*CD2))*t
    dCD3dt =((vmax*CA*CD2)/(kdna*katp+kdna*CA+katp*CD2+CA*CD2))*t-((vmax*CA*CD3)/(kdna*katp+kdna*CA+katp*CD3+CA*CD3))*t
    dCD4dt =((vmax*CA*CD3)/(kdna*katp+kdna*CA+katp*CD3+CA*CD3))*t-((vmax*CA*CD4)/(kdna*katp+kdna*CA+katp*CD4+CA*CD4))*t
    dCD5dt =((vmax*CA*CD4)/(kdna*katp+kdna*CA+katp*CD4+CA*CD4))*t-((vmax*CA*CD5)/(kdna*katp+kdna*CA+katp*CD5+CA*CD5))*t
    dCD6dt =((vmax*CA*CD5)/(kdna*katp+kdna*CA+katp*CD5+CA*CD5))*t-((vmax*CA*CD6)/(kdna*katp+kdna*CA+katp*CD6+CA*CD6))*t
    dCD7dt =((vmax*CA*CD6)/(kdna*katp+kdna*CA+katp*CD6+CA*CD6))*t-((vmax*CA*CD7)/(kdna*katp+kdna*CA+katp*CD7+CA*CD7))*t
    dCD8dt =((vmax*CA*CD7)/(kdna*katp+kdna*CA+katp*CD7+CA*CD7))*t-((vmax*CA*CD8)/(kdna*katp+kdna*CA+katp*CD8+CA*CD8))*t
    dCD9dt =((vmax*CA*CD8)/(kdna*katp+kdna*CA+katp*CD8+CA*CD8))*t-((vmax*CA*CD9)/(kdna*katp+kdna*CA+katp*CD9+CA*CD9))*t
    dCD10dt =((vmax*CA*CD9)/(kdna*katp+kdna*CA+katp*CD9+CA*CD9))*t-((vmax*CA*CD10)/(kdna*katp+kdna*CA+katp*CD10+CA*CD10))*t
    dCD11dt =((vmax*CA*CD10)/(kdna*katp+kdna*CA+katp*CD10+CA*CD10))*t-((vmax*CA*CD11)/(kdna*katp+kdna*CA+katp*CD11+CA*CD11))*t
    dCD12dt =((vmax*CA*CD11)/(kdna*katp+kdna*CA+katp*CD11+CA*CD11))*t-((vmax*CA*CD12)/(kdna*katp+kdna*CA+katp*CD12+CA*CD12))*t
    dCD13dt =((vmax*CA*CD12)/(kdna*katp+kdna*CA+katp*CD12+CA*CD12))*t-((vmax*CA*CD13)/(kdna*katp+kdna*CA+katp*CD13+CA*CD13))*t
    dCD14dt =((vmax*CA*CD13)/(kdna*katp+kdna*CA+katp*CD13+CA*CD13))*t-((vmax*CA*CD14)/(kdna*katp+kdna*CA+katp*CD14+CA*CD14))*t
    dCD15dt =((vmax*CA*CD14)/(kdna*katp+kdna*CA+katp*CD14+CA*CD14))*t-((vmax*CA*CD15)/(kdna*katp+kdna*CA+katp*CD15+CA*CD15))*t
    dCD16dt =((vmax*CA*CD15)/(kdna*katp+kdna*CA+katp*CD15+CA*CD15))*t-((vmax*CA*CD16)/(kdna*katp+kdna*CA+katp*CD16+CA*CD16))*t
    dCD17dt =((vmax*CA*CD16)/(kdna*katp+kdna*CA+katp*CD16+CA*CD16))*t-((vmax*CA*CD17)/(kdna*katp+kdna*CA+katp*CD17+CA*CD17))*t
    dCD18dt =((vmax*CA*CD17)/(kdna*katp+kdna*CA+katp*CD17+CA*CD17))*t-((vmax*CA*CD18)/(kdna*katp+kdna*CA+katp*CD18+CA*CD18))*t
    dCD19dt =((vmax*CA*CD18)/(kdna*katp+kdna*CA+katp*CD18+CA*CD18))*t-((vmax*CA*CD19)/(kdna*katp+kdna*CA+katp*CD19+CA*CD19))*t
    dCD20dt =((vmax*CA*CD19)/(kdna*katp+kdna*CA+katp*CD19+CA*CD19))*t-((vmax*CA*CD20)/(kdna*katp+kdna*CA+katp*CD20+CA*CD20))*t
    dCD21dt =((vmax*CA*CD20)/(kdna*katp+kdna*CA+katp*CD20+CA*CD20))*t-((vmax*CA*CD21)/(kdna*katp+kdna*CA+katp*CD21+CA*CD21))*t
    dCD22dt =((vmax*CA*CD21)/(kdna*katp+kdna*CA+katp*CD21+CA*CD21))*t-((vmax*CA*CD22)/(kdna*katp+kdna*CA+katp*CD22+CA*CD22))*t
    dCD23dt =((vmax*CA*CD22)/(kdna*katp+kdna*CA+katp*CD22+CA*CD22))*t-((vmax*CA*CD23)/(kdna*katp+kdna*CA+katp*CD23+CA*CD23))*t
    dCD24dt =((vmax*CA*CD23)/(kdna*katp+kdna*CA+katp*CD23+CA*CD23))*t-((vmax*CA*CD24)/(kdna*katp+kdna*CA+katp*CD24+CA*CD24))*t
    dCD25dt =((vmax*CA*CD24)/(kdna*katp+kdna*CA+katp*CD24+CA*CD24))*t-((vmax*CA*CD25)/(kdna*katp+kdna*CA+katp*CD25+CA*CD25))*t
    dCD26dt =((vmax*CA*CD25)/(kdna*katp+kdna*CA+katp*CD25+CA*CD25))*t-((vmax*CA*CD26)/(kdna*katp+kdna*CA+katp*CD26+CA*CD26))*t
    dCD27dt =((vmax*CA*CD26)/(kdna*katp+kdna*CA+katp*CD26+CA*CD26))*t-((vmax*CA*CD27)/(kdna*katp+kdna*CA+katp*CD27+CA*CD27))*t
    dCD28dt =((vmax*CA*CD27)/(kdna*katp+kdna*CA+katp*CD27+CA*CD27))*t-((vmax*CA*CD28)/(kdna*katp+kdna*CA+katp*CD28+CA*CD28))*t
    dCD29dt =((vmax*CA*CD28)/(kdna*katp+kdna*CA+katp*CD28+CA*CD28))*t-((vmax*CA*CD29)/(kdna*katp+kdna*CA+katp*CD29+CA*CD29))*t
    dCD30dt =((vmax*CA*CD29)/(kdna*katp+kdna*CA+katp*CD29+CA*CD29))*t
  
    
    return [dCAdt, dCDdt, dCD1dt, dCD2dt, dCD3dt, dCD4dt, dCD5dt, dCD6dt, dCD7dt, dCD8dt, dCD9dt, dCD10dt, dCD11dt, dCD12dt, dCD13dt, dCD14dt, dCD14dt, dCD16dt, dCD17dt, dCD18dt, dCD19dt, dCD20dt, dCD21dt, dCD22dt, dCD23dt, dCD24dt, dCD25dt, dCD26dt, dCD27dt, dCD28dt, dCD29dt, dCD30dt]

x0 = [ATP, 2*10**-8,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]
Integrationtime = 120
stepwidth = 0.01

t = np.arange(0,Integrationtime,stepwidth)
              
x = odeint(concentrations, x0, t)


# In[4]:


### Konzentrationsverläufe c gegen t


# In[15]:



CD = x[:,1]
CD1 = x[:,2]
CA = x[:,0]
CD2 = x[:,3]
CD3 = x[:,4]
CD4 = x[:,5]
CD5 = x[:,6]
CD6 = x[:,7]
CD7 = x[:,8]
CD8 = x[:,9]
CD9 = x[:,10]
CD10 = x[:,11]
CD11 = x[:,12]


CD28 = x[:,29]
CD29 = x[:,30]
CD30 = x[:,31]

plt.plot(t,CD,label='DNA0')
plt.plot(t,CD1,label='DNA1')
plt.plot(t,CD2,label='DNA2')
plt.plot(t, CD3,label='DNA3')

plt.xlabel('time [s]')
plt.ylabel('concentration')


plt.legend()
plt.show()


# In[ ]:




